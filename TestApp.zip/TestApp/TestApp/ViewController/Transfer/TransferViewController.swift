//
//  TransferViewController.swift
//  TestApp
//
//  Created by Rajkumar on 26/9/21.
//  Copyright © 2021 Rajkumar. All rights reserved.
//


import Foundation

import UIKit

class TransferViewController: UIViewController, UITextFieldDelegate {

    @IBOutlet weak var recipient : UITextField?
    @IBOutlet weak var dateofTransfer : UITextField?
    @IBOutlet weak var transferDescription : UITextField?
    @IBOutlet weak var transferAmount : UITextField?
    @IBOutlet weak var recipientBtn : UIButton?
    @IBOutlet weak var calendarBtn : UIButton?
    @IBOutlet weak var cancelBtn : UIButton?
    @IBOutlet weak var submitBtn : UIButton?
    @IBOutlet weak var logoutBtn : UIButton?
    //@IBOutlet weak var myDatePicker: UIDatePicker!
    var selectedAccName : String = ""
    var accountNo : String = ""
    var transferService = TransferService()
    let datePicker = UIDatePicker()
   
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        self.navigationController?.isNavigationBarHidden = true
        transferService.subDelegate = self
        createDatePicker()
        self.submitBtn?.isEnabled = false
        self.cancelBtn?.isEnabled = false
        transferAmount?.delegate = self
        
    }
    
    override func viewWillAppear(_ animated: Bool) {
        recipient?.text = selectedAccName
        submitBtnDisable()
    }

    func submitBtnDisable() {
        [recipient, dateofTransfer,transferDescription,transferAmount].forEach {
            $0?.addTarget(self,
                          action: #selector(editingChanged(_:)),
                          for: .editingChanged)
        }
    }
    @objc func editingChanged(_ textField: UITextField) {
        textField.text = textField.text?.trimmingCharacters(in: .whitespacesAndNewlines)
        submitBtn!.isEnabled = ![recipient, dateofTransfer,transferDescription,transferAmount].compactMap {
                $0!.text?.isEmpty
            }.contains(true)
        cancelBtn!.isEnabled = ![recipient, dateofTransfer,transferDescription,transferAmount].compactMap {
            $0!.text?.isEmpty
        }.contains(true)
    }
    
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        if textField == transferAmount {
            let allowedCharacters = CharacterSet(charactersIn:"0123456789")
            let characterSet = CharacterSet(charactersIn: string)
            return allowedCharacters.isSuperset(of: characterSet)
        }
        return true
    }
    
    @IBAction func selectRecipient(_ sender: UIButton) {
        let storyBoard : UIStoryboard = UIStoryboard(name: "Main", bundle:nil)
        let nextViewController = storyBoard.instantiateViewController(withIdentifier: "PayeeListViewController") as! PayeeListViewController
        nextViewController.subDelegate = self
        self.present(nextViewController, animated: true, completion: nil)
       }
    
    @IBAction func selectDate(_ sender: UIButton) {
        self.createDatePicker()
    }
    
    
    @IBAction func submitTransfer(_ sender: UIButton) {
        transferService.transferFund(accountNo: "acc", amount: 100, transferDate: "tranferdate", description: "description")
    }
    
    @IBAction func cancelTransfer(_ sender: UIButton) {
        recipient?.text = ""
        dateofTransfer?.text = ""
        transferDescription?.text = ""
        transferAmount?.text = ""
        self.submitBtn?.isEnabled = false
    }
    
    @IBAction func logout(_ sender: UIButton) {
        recipient?.text = ""
        dateofTransfer?.text = ""
        transferDescription?.text = ""
        transferAmount?.text = ""
        let storyBoard : UIStoryboard = UIStoryboard(name: "Main", bundle:nil)
        let nextViewController = storyBoard.instantiateViewController(withIdentifier: "ViewController") as! ViewController
        self.navigationController?.pushViewController(nextViewController, animated: true)
    }
    
    func createDatePicker() {
        let toolbar = UIToolbar()
        toolbar.sizeToFit()
        let donebtn = UIBarButtonItem(barButtonSystemItem: .done, target: nil, action: #selector(donepressed))
        toolbar.setItems([donebtn], animated: true)
        dateofTransfer?.inputAccessoryView = toolbar
        dateofTransfer?.inputView = datePicker
        datePicker.datePickerMode = .date
        
        
    }
    
    @objc func donepressed() {
        let dateformator = DateFormatter()
        dateformator.dateStyle = .medium
        dateformator.timeStyle = .none
        dateofTransfer?.text = dateformator.string(from: datePicker.date)
        self.view.endEditing(true)
    }
   
}

extension TransferViewController : TransferModelDelegate, PayeeSelectDelegate {
    
    func getSelectedPayee(accName: String, accNo: String) {
        recipient?.text = accName
    }
    
    func transferSuccess(transferMessage : String?) {
        let alert = UIAlertController(title: "Transfer Completed", message: transferMessage, preferredStyle: UIAlertController.Style.alert)
        alert.addAction(UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: nil))
        self.present(alert, animated: true, completion: nil)
    }
    func transferFailure(failure: String?) {
        let alert = UIAlertController(title: "Transfer Failed", message: failure, preferredStyle: UIAlertController.Style.alert)
        alert.addAction(UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: nil))
        self.present(alert, animated: true, completion: nil)
    }
}


//
//  PayListViewController.swift
//  TestApp
//
//  Created by Rajkumar on 26/9/21.
//  Copyright © 2021 Rajkumar. All rights reserved.
//

import Foundation

import UIKit

protocol PayeeSelectDelegate {
    
    func getSelectedPayee(accName : String, accNo : String)
}

class PayeeListViewController: UIViewController, UITableViewDelegate, UITableViewDataSource{

   @IBOutlet weak var payeeList : UITableView?
   @IBOutlet weak var cancel : UIButton?
    var resaccountNames : [payeeData] = []
    var payeeService = PayeeService()
    var subDelegate : PayeeSelectDelegate?
    override func viewDidLoad() {
        super.viewDidLoad()
        payeeService.subDelegate = self
        self.payeeService.getPayeeList()
        self.payeeList?.dataSource = self
        self.payeeList?.delegate = self
        self.navigationItem.setHidesBackButton(false, animated: true)
        self.navigationItem.title = "Payee List"
        self.payeeList?.tableFooterView = UIView()
    }

    @IBAction func cancel(_ sender: UIButton) {
        self.dismiss(animated: true, completion: nil)
    }
   
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
         return resaccountNames.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cellReuseIdentifier")!
        cell.textLabel?.text = resaccountNames[indexPath.row].accountHolderName
        return cell
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        self.subDelegate?.getSelectedPayee(accName : resaccountNames[indexPath.row].accountHolderName!,accNo : resaccountNames[indexPath.row].accountNo!)
        self.dismiss(animated: true, completion: nil)
        
    }
}

extension PayeeListViewController : PayeeLstDelegate {
   
    func getPayeeSuccess(responses: payeeResponseData?) {
        resaccountNames = (responses?.data)!
        self.payeeList?.reloadData()
    }
    
    func getPayeeFailure(failureMessage: String?) {
        let alert = UIAlertController(title: "Get Payee Failed", message: failureMessage, preferredStyle: UIAlertController.Style.alert)
        alert.addAction(UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: nil))
        self.present(alert, animated: true, completion: nil)
    }
 }


//
//  PayListViewController.swift
//  TestApp
//
//  Created by Rajkumar on 25/9/21.
//  Copyright © 2021 Rajkumar. All rights reserved.
//

import Foundation

import UIKit

class PayeeListViewController: UIViewController, UITableViewDelegate, UITableViewDataSource{

   @IBOutlet weak var payeeList : UITableView?
   @IBOutlet weak var cancel : UIButton?
    var accountNos = ["8013-777-3232Z","4489-991-0023","1234-000-1234","8182-321-9921"]
    var accountNames = ["Jason","Jane","Max Yee","Daniel"]
    //var accountNames : [String] = []
   // var accountNos : [String] = []
    var payeeService = PayeeService()
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
       // self.navigationController?.isNavigationBarHidden = true
        payeeService.subDelegate = self
        self.payeeService.getPayeeList()
        
        self.payeeList?.dataSource = self
        self.payeeList?.delegate = self
        self.navigationItem.setHidesBackButton(true, animated: true)
        self.navigationItem.title = "Payee List"
    }

    @IBAction func cancel(_ sender: UIButton) {
        self.dismiss(animated: true, completion: nil)
    }
   
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
       // if let AccountNames = accountNames {
            return accountNames.count
       // }
       
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cellReuseIdentifier")!
        //if let accountName = accountNames {
            cell.textLabel?.text = accountNames[indexPath.row]
        //}
        return cell
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if let vc = storyboard?.instantiateViewController(identifier: "TransferViewController") as? TransferViewController {
            vc.selectedAccName = accountNames[indexPath.row]
            vc.accountNo = accountNos[indexPath.row]
            self.navigationController?.pushViewController(vc, animated: true)
        }
    }
}

extension PayeeListViewController : PayeeLstDelegate {
    func getPayeeSuccess(responses: [Any]?) {
        //print(responses?[2])
       //var payeeData: payeeResponseData
        
       
         for item in responses! {
            print(item)
            switch item {
            case let payeedata as PayeeService.payeeResponseData:
                print(payeedata.data)
            
                default:
                    print("something")
            }
         }
    }
    func getPayeeFailure() {
        
    }
    
    func getPayeeSuccess() {
        
    }
    
    
    
    
}


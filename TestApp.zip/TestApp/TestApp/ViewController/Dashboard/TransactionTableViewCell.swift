//
//  TransactionTableViewCell.swift
//  TestApp
//
//  Created by tmpr48 on 27/9/21.
//  Copyright © 2021 Rajkumar. All rights reserved.
//

import Foundation
import UIKit

class TransactionTableViewCell : UITableViewCell {
    
    @IBOutlet var dateColumn : UILabel?
    @IBOutlet var desColumn : UILabel?
    @IBOutlet var amtColumn : UILabel?
    
    
}


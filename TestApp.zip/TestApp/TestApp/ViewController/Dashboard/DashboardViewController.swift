//
//  DashboardViewController.swift
//  TestApp
//
//  Created by Rajkumar on 26/9/21.
//  Copyright © 2021 Rajkumar. All rights reserved.
//

import UIKit

class DashboardViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {

    @IBOutlet weak var balance : UILabel?
    @IBOutlet weak var logoutButton : UIButton?
    @IBOutlet weak var payTransferButton : UIButton?
    @IBOutlet weak var transactionList : UITableView?
    var dashBoardService = DashboardService()
    var trnanactionService = TransactionService()
    var transactionListData : [transactionDetailData] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        self.navigationController?.isNavigationBarHidden = true
        dashBoardService.subDelegate = self
        trnanactionService.subDelegate = self
        self.dashBoardService.getBalance()
        self.transactionList?.dataSource = self
        self.transactionList?.delegate = self
    }

    @IBAction func logout(_ sender: UIButton) {
        let storyBoard : UIStoryboard = UIStoryboard(name: "Main", bundle:nil)
                   let nextViewController = storyBoard.instantiateViewController(withIdentifier: "ViewController") as! ViewController
                   self.navigationController?.pushViewController(nextViewController, animated: true)
        }
    
    @IBAction func makeTransfer(_ sender: UIButton) {
                let storyBoard : UIStoryboard = UIStoryboard(name: "Main", bundle:nil)
               let nextViewController = storyBoard.instantiateViewController(withIdentifier: "TransferViewController") as! TransferViewController
               self.navigationController?.pushViewController(nextViewController, animated: true)
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
         return transactionListData.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cellReuseIdentifier") as! TransactionTableViewCell
        cell.dateColumn?.text = dateformat(receivedDate : transactionListData[indexPath.row].date!)
        cell.desColumn?.text = transactionListData[indexPath.row].description
        let amount = transactionListData[indexPath.row].amount
        let amountStr : String = String(format: "%.2f",amount as! CVarArg)
        if let recType = transactionListData[indexPath.row].type {
            cell.amtColumn?.text = checkTransactionType(receivedType : recType,receivedAmount : amountStr)
            //cell.amtColumn?.textColor = UIColor.green
        }
        return cell
    }
    
    func dateformat(receivedDate : String) -> String {
        let formatter = Foundation.DateFormatter()
        formatter.dateFormat = "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'"
        let dateOne  = formatter.date(from: receivedDate)
        formatter.dateFormat = "dd MMM"
        let resultTime = formatter.string(from: dateOne!)
        return resultTime
    }
   
    func checkTransactionType(receivedType : String, receivedAmount : String) -> String {
        var finalString : String = ""
        switch receivedType {
        case "transfer":
            print(receivedType)
            finalString = "- " + receivedAmount
            break
            
        case "receive":
            print(receivedType)
            finalString = receivedAmount
            break
            
        default:
            break
        }
        return finalString
    }
}
    
extension DashboardViewController : DashboardDelegate, TransactionDelegate {
    
    func getTransactionFailure(failureMessage: String?) {
         let alert = UIAlertController(title: "Get Transaction Failed", message: failureMessage, preferredStyle: UIAlertController.Style.alert)
               alert.addAction(UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: nil))
               self.present(alert, animated: true, completion: nil)
    }
    
    func getTransactionDetails(responses: transactionData) {
        transactionListData = (responses.data)!
        self.transactionList?.reloadData()
    }
    
    func getBalanceSuccess(balance : Int) {
        let prefix : String = "SGD "
        let formatter = NumberFormatter()
        formatter.numberStyle = NumberFormatter.Style.decimal
        let formattedString = formatter.string(from: NSNumber(value: balance))
        self.balance?.text = prefix + (formattedString)!
        //self.balance?.text = "SGD " + String(balance)
        self.trnanactionService.getTranactionList()
    }
    func getBalanceFailure(failureMessage : String) {
        let alert = UIAlertController(title: "Get Balance Failed", message: failureMessage, preferredStyle: UIAlertController.Style.alert)
        alert.addAction(UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: nil))
        self.present(alert, animated: true, completion: nil)
    }
    
}

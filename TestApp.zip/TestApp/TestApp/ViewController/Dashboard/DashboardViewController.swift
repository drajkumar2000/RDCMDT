//
//  DashboardViewController.swift
//  TestApp
//
//  Created by Rajkumar on 25/9/21.
//  Copyright © 2021 Rajkumar. All rights reserved.
//

import UIKit

class DashboardViewController: UIViewController {

    @IBOutlet weak var balance : UILabel?
    @IBOutlet weak var logoutButton : UIButton?
    @IBOutlet weak var payTransferButton : UIButton?
    var dashBoardService = DashboardService()
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        self.navigationController?.isNavigationBarHidden = true
        dashBoardService.subDelegate = self
        self.dashBoardService.getBalance()
        
    }

    @IBAction func logout(_ sender: UIButton) {
        let storyBoard : UIStoryboard = UIStoryboard(name: "Main", bundle:nil)
                   let nextViewController = storyBoard.instantiateViewController(withIdentifier: "ViewController") as! ViewController
                   self.navigationController?.pushViewController(nextViewController, animated: true)
        }
    
    @IBAction func makeTransfer(_ sender: UIButton) {
                let storyBoard : UIStoryboard = UIStoryboard(name: "Main", bundle:nil)
               let nextViewController = storyBoard.instantiateViewController(withIdentifier: "TransferViewController") as! TransferViewController
               self.navigationController?.pushViewController(nextViewController, animated: true)
    }
    
}
    
extension DashboardViewController : DashboardDelegate {
    func getBalanceSuccess(balance : Int) {
        self.balance?.text = String(balance)
    }
    func getBalanceFailure() {
        
    }
}

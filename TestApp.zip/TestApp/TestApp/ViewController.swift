//
//  ViewController.swift
//  TestApp
//
//  Created by Rajkumar on 25/9/21.
//  Copyright © 2021 Rajkumar. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UITextFieldDelegate {
    
    @IBOutlet weak var userName : UITextField?
    @IBOutlet weak var password : UITextField?
    @IBOutlet weak var loginButton : UIButton?
    var loginService = LoginService()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        self.navigationController?.isNavigationBarHidden = true
        loginService.subDelegate=self;
        self.loginButton?.backgroundColor = UIColor.gray
        self.loginButton?.layer.cornerRadius = 10
        self.loginButton?.isEnabled = false
        [userName, password].forEach {
            $0?.addTarget(self,
                          action: #selector(editingChanged(_:)),
                          for: .editingChanged)
        }
        
    }
    @objc func editingChanged(_ textField: UITextField) {
        
        // Trim whitespace and newlines
        textField.text = textField.text?.trimmingCharacters(in: .whitespacesAndNewlines)
        
        // Assumes loginButton exists and there's a reference to it in the current scope.
        loginButton!.isEnabled = ![userName, password].compactMap {
            $0!.text?.isEmpty
        }.contains(true)
    }
    func loaderShow () {
        let alert = UIAlertController(title: nil, message: "Please wait...", preferredStyle: .alert)
        let loadingIndicator = UIActivityIndicatorView(frame: CGRect(x: 10, y: 5, width: 50, height: 50))
        loadingIndicator.hidesWhenStopped = true
        loadingIndicator.style = UIActivityIndicatorView.Style.medium
        loadingIndicator.startAnimating();
        alert.view.addSubview(loadingIndicator)
        present(alert, animated: true, completion: nil)
    }
    @IBAction func loginTapped(_ sender: UIButton) {
        
        /*if ((userName?.text!.isEmpty) ) || ((password?.text?.isEmpty) ) {
            let alert = UIAlertController(title: "Alert", message: "Username/Password is required", preferredStyle: UIAlertController.Style.alert)
            alert.addAction(UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: nil))
            self.present(alert, animated: true, completion: nil)
        }*/
        
        
        if let userName = userName?.text , let pwd = password?.text  {
            self.loginService.login(userName: userName, password: pwd)
            
        } else {
            
        }
        
        
    }
    
}

extension ViewController: LoginModelDelegate {
    
    func loginSuccess() {
        let storyBoard : UIStoryboard = UIStoryboard(name: "Main", bundle:nil)
               let nextViewController = storyBoard.instantiateViewController(withIdentifier: "DashboardViewController") as! DashboardViewController
               self.navigationController?.pushViewController(nextViewController, animated: true)
    }
    
    func loginFailure() {
        
    }
    
}

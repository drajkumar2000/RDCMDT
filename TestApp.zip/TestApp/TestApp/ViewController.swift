//
//  ViewController.swift
//  TestApp
//
//  Created by Rajkumar on 26/9/21.
//  Copyright © 2021 Rajkumar. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UITextFieldDelegate {
    
    @IBOutlet weak var userName : UITextField?
    @IBOutlet weak var password : UITextField?
    @IBOutlet weak var loginButton : UIButton?
    var loginService = LoginService()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        self.navigationController?.isNavigationBarHidden = true
        loginService.subDelegate=self;
        self.loginButton?.backgroundColor = UIColor.gray
        self.loginButton?.layer.cornerRadius = 10
        self.loginButton?.isEnabled = false
        [userName, password].forEach {
            $0?.addTarget(self,
                          action: #selector(editingChanged(_:)),
                          for: .editingChanged)
        }
        
    }
    @objc func editingChanged(_ textField: UITextField) {
        textField.text = textField.text?.trimmingCharacters(in: .whitespacesAndNewlines)
        loginButton!.isEnabled = ![userName, password].compactMap {
            $0!.text?.isEmpty
        }.contains(true)
    }
    
    @IBAction func loginTapped(_ sender: UIButton) {
        if let userName = userName?.text , let pwd = password?.text  {
            self.loginService.login(userName: userName, password: pwd)
        }
      }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }
}

extension ViewController: LoginModelDelegate {
    
    func loginSuccess() {
        let storyBoard : UIStoryboard = UIStoryboard(name: "Main", bundle:nil)
               let nextViewController = storyBoard.instantiateViewController(withIdentifier: "DashboardViewController") as! DashboardViewController
               self.navigationController?.pushViewController(nextViewController, animated: true)
    }
    
    func loginFailure(failureMessage : String) {
        let alert = UIAlertController(title: "Login Failed", message: failureMessage, preferredStyle: UIAlertController.Style.alert)
        alert.addAction(UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: nil))
        self.present(alert, animated: true, completion: nil)
    }
    
}


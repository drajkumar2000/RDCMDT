//
//  transactionResponseModel.swift
//  TestApp
//
//  Created by Rajkumar on 26/9/21.
//  Copyright © 2021 Rajkumar. All rights reserved.
//

import Foundation


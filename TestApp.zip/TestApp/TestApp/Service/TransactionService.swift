//
//  TransactionService.swift
//  TestApp
//
//  Created by tmpr48 on 27/9/21.
//  Copyright © 2021 Rajkumar. All rights reserved.
//

import Foundation
import UIKit

struct transactionData : Codable {
     let status : String?
     let data : [transactionDetailData]?
     
 }

struct transactionDetailData : Codable {
    let id, type : String?
    let amount : Double?
    let currency: String?
    let from: From?
    let description: String?
    let date : String?
    let to : From?
    
}

struct From : Codable {
    let accountNo, accountHolderName: String?
}

protocol TransactionDelegate {
    func getTransactionDetails(responses : transactionData)
    func getTransactionFailure (failureMessage : String?)
}
class TransactionService : NSObject {

    override init() {
        super.init()
    }
    var subDelegate : TransactionDelegate?
    
    func getTranactionList() {
        
        let transactionEndPoint = "http://localhost:8080/account/transactions"
        
        guard let url = URL(string: transactionEndPoint) else {
            return
        }
        
        let session = URLSession.shared
        var request = URLRequest(url: url)
        request.httpMethod = "GET"
        request.setValue("application/josn", forHTTPHeaderField: "Content-type")
        request.setValue("application/josn", forHTTPHeaderField: "Accept")
        if let key = UserDefaults.standard.string(forKey: "userToken") {
            request.setValue("Authorization", forHTTPHeaderField: key)
        }
        
        //request.httpBody = jsonData
        
        let getTransactionCompletionHandler: (Data?, URLResponse?, Error?) -> Void = {
            (data, response, error) in
             if let response = response {
                print(response)
            }
            if let error = error {
                print (error)
            }
            //Below two line code is commented due to - nw_socket_output_finished [C1.1:2] shutdown(9, SHUT_WR) [57: Socket is not connected]
           // if let data = data {
               //if let decodeResponse = try? JSONDecoder().decode(loginResponseData.self, from: data) {
                     //print(decodeResponse)
                    do {
                        if let bundlePath = Bundle.main.path(forResource: "transactionsResponse",
                                                             ofType: "json"),
                            let jsonData = try String(contentsOfFile: bundlePath).data(using: .utf8) {
                            print(jsonData)
                            let transactionResponseData = try JSONDecoder().decode(transactionData.self,
                            from: jsonData)
                            
                            if transactionResponseData.status == "success" {
                               //if let responseData = transactionResponseData {
                                   DispatchQueue.main.async {
                                        self.subDelegate?.getTransactionDetails(responses: transactionResponseData)
                                    }
                                //}
                            } else {
                                if let status = transactionResponseData.status {
                                    DispatchQueue.main.async {
                                       self.subDelegate?.getTransactionFailure(failureMessage: status)
                                  }
                                }
                               
                                
                            }
                         }
                    } catch {
                        print(error)
                    }
                //}
            //}
        }
        let task = session.dataTask(with: request, completionHandler: getTransactionCompletionHandler)
        task.resume()
    }
   
    
}


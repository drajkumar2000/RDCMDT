//
//  PayeeResponse.swift
//  TestApp
//
//  Created by Rajkumar on 26/9/21.
//  Copyright © 2021 Rajkumar. All rights reserved.
//

import Foundation
import UIKit
/*struct payeeResponseData : Codable {
      var status : String?
      var data : [payeeData]?
    
    enum CodingKeys: String, CodingKey {
        case satus = "status"
        case data = "data"
    }
    
     init(from decoder: Decoder) throws {
        let values = try decoder.container(keyedBy: CodingKeys.self)
        status = try values.decode(String.self, forKey: .satus)
        data = try values.decode([payeeData].self, forKey: .data)
    }
 }

 struct payeeData : Codable {
    public let id, accountNo, accountHolderName: String?
}

*/

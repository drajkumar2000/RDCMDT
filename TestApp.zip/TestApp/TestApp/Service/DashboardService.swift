//
//  DashboardService.swift
//  TestApp
//
//  Created by Rajkumar on 26/9/21.
//  Copyright © 2021 Rajkumar. All rights reserved.
//

import Foundation
import UIKit

protocol DashboardDelegate {
    func getBalanceSuccess(balance : Int)
    func getBalanceFailure(failureMessage : String)
}
class DashboardService : NSObject {

    override init() {
        super.init()
    }
    var subDelegate : DashboardDelegate?
    struct balanceResponseData : Codable {
         let status : String?
         let balance : Int?
     }
    
    func getBalance () {
        
        let balanceEndPoint = "http://localhost:8080/account/balances"
        
        guard let url = URL(string: balanceEndPoint) else {
            return
        }
        
        let session = URLSession.shared
        var request = URLRequest(url: url)
        request.httpMethod = "GET"
        request.setValue("application/josn", forHTTPHeaderField: "Content-type")
        request.setValue("application/josn", forHTTPHeaderField: "Accept")
        if let key = UserDefaults.standard.string(forKey: "userToken") {
            request.setValue("Authorization", forHTTPHeaderField: key)
        }
        
        //request.httpBody = jsonData
        
        let getBalanceCompletionHandler: (Data?, URLResponse?, Error?) -> Void = {
            (data, response, error) in
             if let response = response {
                print(response)
            }
            if let error = error {
                print (error)
            }
            //Below two line code is commented due to - nw_socket_output_finished [C1.1:2] shutdown(9, SHUT_WR) [57: Socket is not connected]
           // if let data = data {
               //if let decodeResponse = try? JSONDecoder().decode(loginResponseData.self, from: data) {
                     //print(decodeResponse)
                    do {
                        if let bundlePath = Bundle.main.path(forResource: "balanceResponse",
                                                             ofType: "json"),
                            let jsonData = try String(contentsOfFile: bundlePath).data(using: .utf8) {
                            print(jsonData)
                            let decodedData = try JSONDecoder().decode(balanceResponseData.self,
                            from: jsonData)
                            print("Status: ", decodedData.status ?? nil ?? "")
                            print("balance: ", decodedData.balance ?? 0)
                            if decodedData.status == "success" {
                                if let balance = decodedData.balance {
                                    DispatchQueue.main.async {
                                        self.subDelegate?.getBalanceSuccess(balance: balance )
                                    }
                                }
                            } else {
                                if let status = decodedData.status {
                                    DispatchQueue.main.async {
                                        self.subDelegate?.getBalanceFailure(failureMessage : status)
                                    }
                                }
                            }
                          }
                    } catch {
                        print(error)
                    }
                //}
            //}
        }
        let task = session.dataTask(with: request, completionHandler: getBalanceCompletionHandler)
        task.resume()
    }
    
    func gettransactions () {
        
        let balanceEndPoint = "http://localhost:8080/account/transactions"
        
        guard let url = URL(string: balanceEndPoint) else {
            return
        }
        
        let session = URLSession.shared
        var request = URLRequest(url: url)
        request.httpMethod = "GET"
        request.setValue("application/josn", forHTTPHeaderField: "Content-type")
        request.setValue("application/josn", forHTTPHeaderField: "Accept")
        if let key = UserDefaults.standard.string(forKey: "userToken") {
            request.setValue("application/josn", forHTTPHeaderField: key)
        }
        
        //request.httpBody = jsonData
        
        let getBalanceCompletionHandler: (Data?, URLResponse?, Error?) -> Void = {
            (data, response, error) in
             if let response = response {
                print(response)
            }
            if let error = error {
                print (error)
            }
            //if let data = data {
               //if let decodeResponse = try? JSONDecoder().decode(loginResponseData.self, from: data) {
                     //print(decodeResponse)
                    do {
                        if let bundlePath = Bundle.main.path(forResource: "balanceResponse",
                                                             ofType: "json"),
                            let jsonData = try String(contentsOfFile: bundlePath).data(using: .utf8) {
                            print(jsonData)
                            let decodedData = try JSONDecoder().decode(balanceResponseData.self,
                            from: jsonData)
                            print("Status: ", decodedData.status ?? nil ?? "")
                            print("balance: ", decodedData.balance ?? 0)
                            if decodedData.status == "success" {
                                if let balance = decodedData.balance {
                                    DispatchQueue.main.async {
                                        self.subDelegate?.getBalanceSuccess(balance: balance )
                                    }
                                }
                            }
                        }
                    } catch {
                        print(error)
                    }
                //}
            //}
        }
        let task = session.dataTask(with: request, completionHandler: getBalanceCompletionHandler)
        task.resume()
    }
}

//
//  PayeeService.swift
//  TestApp
//
//  Created by Rajkumar on 26/9/21.
//  Copyright © 2021 Rajkumar. All rights reserved.
//

import Foundation
import UIKit

struct payeeResponseData : Codable {
     let status : String?
     let data : [payeeData]?
 }

struct payeeData : Codable {
    let id, accountNo, accountHolderName: String?
}

protocol PayeeLstDelegate {
    func getPayeeSuccess(responses : payeeResponseData?)
    func getPayeeFailure(failureMessage : String?)
}
class PayeeService : NSObject {

    override init() {
        super.init()
    }
    var subDelegate : PayeeLstDelegate?
    typealias payeeDataCallBack = (_ payeeResponseDatas:[payeeResponseData]?, _ status: Bool, _ message:String) -> Void
    var callBack:payeeDataCallBack?
    
    
    func getPayeeList() {
        
        let payeeEndPoint = "http://localhost:8080/account/payees"
        
        guard let url = URL(string: payeeEndPoint) else {
            return
        }
        
        let session = URLSession.shared
        var request = URLRequest(url: url)
        request.httpMethod = "GET"
        request.setValue("application/josn", forHTTPHeaderField: "Content-type")
        request.setValue("application/josn", forHTTPHeaderField: "Accept")
        if let key = UserDefaults.standard.string(forKey: "userToken") {
            request.setValue("Authorization", forHTTPHeaderField: key)
        }
        
        //request.httpBody = jsonData
        
        let getPayeeCompletionHandler: (Data?, URLResponse?, Error?) -> Void = {
            (data, response, error) in
             if let response = response {
                print(response)
            }
            if let error = error {
                print (error)
            }
            //Below two line code is commented due to - nw_socket_output_finished [C1.1:2] shutdown(9, SHUT_WR) [57: Socket is not connected]
           // if let data = data {
               //if let decodeResponse = try? JSONDecoder().decode(loginResponseData.self, from: data) {
                     //print(decodeResponse)
                    do {
                        if let bundlePath = Bundle.main.path(forResource: "payeeResponse",
                                                             ofType: "json"),
                            let jsonData = try String(contentsOfFile: bundlePath).data(using: .utf8) {
                            print(jsonData)
                            let payeeResponseDatas = try JSONDecoder().decode(payeeResponseData.self,
                            from: jsonData)
                            if payeeResponseDatas.status == "success" {
                               if let payeeResponseData = payeeResponseDatas.data {
                                     DispatchQueue.main.async {
                                        self.subDelegate?.getPayeeSuccess(responses: payeeResponseDatas)
                                    }
                                }
                            } else {
                                if let status = payeeResponseDatas.status {
                                     DispatchQueue.main.async {
                                        self.subDelegate?.getPayeeFailure(failureMessage: status)
                                      }
                                }
                               
                            }
                         }
                    } catch {
                        print(error)
                    }
                //}
            //}
        }
        let task = session.dataTask(with: request, completionHandler: getPayeeCompletionHandler)
        task.resume()
    }
    func completionHandler(callBack: @escaping payeeDataCallBack) {
           self.callBack = callBack
       }
    
}

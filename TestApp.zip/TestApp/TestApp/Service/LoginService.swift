//
//  LoginService.swift
//  TestApp
//
//  Created by Rajkumar on 26/9/21.
//  Copyright © 2021 Rajkumar. All rights reserved.
//

import Foundation
import UIKit

protocol LoginModelDelegate {
    func loginSuccess()
    func loginFailure(failureMessage : String)
}
class LoginService : NSObject {
    
    override init() {
        super.init()
    }
    
    var subDelegate : LoginModelDelegate!
    struct loginResponseData : Codable {
        let status : String?
        let token : String?
    }
    struct logineRequstData : Codable {
        let username : String
        let password : String
    }
    func frameLoginRequest(){
        let loginendPoint = "http://localhost:8080/authenticate/login"
        guard URL(string: loginendPoint) != nil else {
            return
        }
    }
    
    func loaderShow () {
        let alert = UIAlertController(title: nil, message: "Please wait...", preferredStyle: .alert)
        let loadingIndicator = UIActivityIndicatorView(frame: CGRect(x: 10, y: 5, width: 50, height: 50))
        loadingIndicator.hidesWhenStopped = true
        //loadingIndicator.style = UIActivityIndicatorView.Style.gray
        loadingIndicator.startAnimating();
        alert.view.addSubview(loadingIndicator)
        //present(alert, animated: true, completion: nil)
    }
    func login (userName : String, password: String) {
        self.loaderShow()
        let loginendPoint = "http://localhost:8080/authenticate/login"
        guard let url = URL(string: loginendPoint) else {
            return
        }
        
       //let loginRequestModel = logineRequstData(username: userName,password: password)
        /*guard let jsonData = try? JSONEncoder().encode(loginRequestModel) else {
            return
        }*/
        let parameters: [String: Any] = [
            "username": userName,
            "password": password
        ]
        let session = URLSession.shared
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.setValue("application/josn", forHTTPHeaderField: "Content-type")
        request.setValue("application/josn", forHTTPHeaderField: "Accept")
        //request.httpBody = jsonData
        do {
            request.httpBody = try JSONSerialization.data(withJSONObject: parameters, options: .prettyPrinted)
        } catch let error {
            print(error.localizedDescription)
        }
        let loginCompletionHoander: (Data?, URLResponse?, Error?) -> Void = {
            (data, response, error) in
             if let response = response {
                print(response)
            }
            if let error = error {
                print (error)
            }
            //Below two line code is commented due to - nw_socket_output_finished [C1.1:2] shutdown(9, SHUT_WR) [57: Socket is not connected]
            //if let data = data {
               //if let decodeResponse = try? JSONDecoder().decode(loginResponseData.self, from: data) {
                     //print(decodeResponse)
                    do {
                        if let bundlePath = Bundle.main.path(forResource: "loginResponse",
                                                             ofType: "json"),
                            let jsonData = try String(contentsOfFile: bundlePath).data(using: .utf8) {
                            print(jsonData)
                            let decodedData = try JSONDecoder().decode(loginResponseData.self,
                            from: jsonData)
                            if decodedData.status == "success" {
                                UserDefaults.standard.set(decodedData.token,forKey: "userToken")
                                UserDefaults.standard.synchronize()
                                UserDefaults.standard.string(forKey: "userToken")
                                DispatchQueue.main.async {
                                    self.subDelegate?.loginSuccess()
                                }
                            } else {
                                if let status = decodedData.status {
                                    DispatchQueue.main.async {
                                        self.subDelegate?.loginFailure(failureMessage : status)
                                    }
                                }
                                
                            }
                        }
                    } catch {
                        print(error)
                    }
                //}
            //}
        }
        let task = session.dataTask(with: request, completionHandler: loginCompletionHoander)
        task.resume()
        
        
    }
}

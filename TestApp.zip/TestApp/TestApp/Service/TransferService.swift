//
//  TransferService.swift
//  TestApp
//
//  Created by Rajkumar on 26/9/21.
//  Copyright © 2021 Rajkumar. All rights reserved.
//

import Foundation

import UIKit

protocol TransferModelDelegate {
    func transferSuccess(transferMessage : String?)
    func transferFailure(failure: String?)
}
class TransferService : NSObject {
    
    override init() {
        super.init()
    }
    
    var subDelegate : TransferModelDelegate!
    struct loginResponseData : Codable {
        let status : String
        let token : String
    }
    struct transferRequstData : Codable {
        let accountNo : String
        let amount : Int
        let transferDate : String
        let description : String
    }
    
    struct transferResponseData : Codable {
        let status : String?
        let description : String?
    }
    
    func transferFund (accountNo : String, amount: Int, transferDate : String, description: String) {
       
        let transferendPoint = "http://localhost:8080/transfer"
        
        guard let url = URL(string: transferendPoint) else {
            return
        }
       let transferRequestModel = transferRequstData(accountNo: accountNo,amount: amount,transferDate: transferDate, description: description)
        /*guard let jsonData = try? JSONEncoder().encode(transferRequestModel) else {
            return
        }*/
        let parameters: [String: Any] = ["mode": "raw",
                                   "dict": ["recipientAccountNo":accountNo,
                                            "amount":amount,
                                            "date":transferDate,
                                            "description": description
                                    ]]
        
        let session = URLSession.shared
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.setValue("application/josn", forHTTPHeaderField: "Content-type")
        request.setValue("application/josn", forHTTPHeaderField: "Accept")
        if let key = UserDefaults.standard.string(forKey: "userToken") {
            request.setValue("Authorization", forHTTPHeaderField: key)
        }
        //request.httpBody = jsonData
        do {
            request.httpBody = try JSONSerialization.data(withJSONObject: parameters, options: .prettyPrinted)
        } catch let error {
            print(error.localizedDescription)
        }
        let transferCompletionHoander: (Data?, URLResponse?, Error?) -> Void = {
            (data, response, error) in
             if let response = response {
                print(response)
            }
            if let error = error {
                print (error)
            }
            //Below two line code is commented due to - nw_socket_output_finished [C1.1:2] shutdown(9, SHUT_WR) [57: Socket is not connected]
            //if let data = data {
               //if let decodeResponse = try? JSONDecoder().decode(transferResponseData.self, from: data) {
                     //print(decodeResponse)
                    do {
                        if let bundlePath = Bundle.main.path(forResource: "transferResponse",
                                                             ofType: "json"),
                            let jsonData = try String(contentsOfFile: bundlePath).data(using: .utf8) {
                            print(jsonData)
                            let decodedData = try JSONDecoder().decode(transferResponseData.self,
                            from: jsonData)
                            //print("Status: ", decodedData.status)
                           // print("description: ", decodedData.description)
                            if decodedData.status == "success" {
                                DispatchQueue.main.async {
                                    if let status = decodedData.description {
                                        DispatchQueue.main.async {
                                            self.subDelegate?.transferSuccess(transferMessage : status)
                                        }
                                    }
                                }
                            } else {
                                if decodedData.status == "failed" {
                                    DispatchQueue.main.async {
                                        if let status = decodedData.description {
                                            DispatchQueue.main.async {
                                                self.subDelegate?.transferFailure(failure: status )
                                            }
                                        }
                                        
                                    }
                                }
                            }
                            
                            
                        }
                    } catch {
                        print(error)
                    }
                //}
            //}
        }
        let task = session.dataTask(with: request, completionHandler: transferCompletionHoander)
       task.resume()
       
    }
}

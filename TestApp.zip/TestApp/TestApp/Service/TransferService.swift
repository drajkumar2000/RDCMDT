//
//  TransferService.swift
//  TestApp
//
//  Created by Rajkumar on 26/9/21.
//  Copyright © 2021 Rajkumar. All rights reserved.
//

import Foundation

import UIKit

protocol TransferModelDelegate {
    func transferSuccess()
    func transferFailure(failure: String)
}
class TransferService : NSObject {
    
    override init() {
        super.init()
    }
    
    var subDelegate : TransferModelDelegate!
    struct loginResponseData : Codable {
        let status : String
        let token : String
    }
    struct transferRequstData : Codable {
        let accountNo : String
        let amount : Int
        let transferDate : String
        let description : String
    }
    
    struct transferResponseData : Codable {
        let status : String?
        let description : String?
    }
    
    func frameLoginRequest(){
        
        let loginendPoint = "http://localhost:8080/transfer"
        guard URL(string: loginendPoint) != nil else {
            return
        }
    }
    
    func loaderShow () {
        let alert = UIAlertController(title: nil, message: "Please wait...", preferredStyle: .alert)

        let loadingIndicator = UIActivityIndicatorView(frame: CGRect(x: 10, y: 5, width: 50, height: 50))
        loadingIndicator.hidesWhenStopped = true
        //loadingIndicator.style = UIActivityIndicatorView.Style.gray
        loadingIndicator.startAnimating();

        alert.view.addSubview(loadingIndicator)
        //present(alert, animated: true, completion: nil)
    }
    func transferFund (accountNo : String, amount: Int, transferDate : String, description: String) {
        //self.loaderShow()
        let transferendPoint = "http://localhost:8080/transfer"
        
        guard let url = URL(string: transferendPoint) else {
            return
        }
       let transferRequestModel = transferRequstData(accountNo: accountNo,amount: amount,transferDate: transferDate, description: description)
        /*guard let jsonData = try? JSONEncoder().encode(transferRequestModel) else {
            return
        }*/
        let parameters: [String: Any] = ["mode": "raw",
                                   "dict": ["recipientAccountNo":"4992-992-9021",
                                            "amount":"100",
                                            "date":"2021-09-12T00:00:00.000Z",
                                            "description": "room rental"
                                    ]]
        
        let session = URLSession.shared
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.setValue("application/josn", forHTTPHeaderField: "Content-type")
        request.setValue("application/josn", forHTTPHeaderField: "Accept")
        if let key = UserDefaults.standard.string(forKey: "userToken") {
            request.setValue("Authorization", forHTTPHeaderField: key)
        }
        //request.httpBody = jsonData
        do {
            request.httpBody = try JSONSerialization.data(withJSONObject: parameters, options: .prettyPrinted)
        } catch let error {
            print(error.localizedDescription)
        }
        let transferCompletionHoander: (Data?, URLResponse?, Error?) -> Void = {
            (data, response, error) in
             if let response = response {
                print(response)
            }
            if let error = error {
                print (error)
            }
            //if let data = data {
               //if let decodeResponse = try? JSONDecoder().decode(transferResponseData.self, from: data) {
                     //print(decodeResponse)
                    do {
                        if let bundlePath = Bundle.main.path(forResource: "transferResponse",
                                                             ofType: "json"),
                            let jsonData = try String(contentsOfFile: bundlePath).data(using: .utf8) {
                            print(jsonData)
                            let decodedData = try JSONDecoder().decode(transferResponseData.self,
                            from: jsonData)
                            //print("Status: ", decodedData.status)
                           // print("description: ", decodedData.description)
                            if decodedData.status == "success" {
                                
                            }
                            if decodedData.status == "failed" {
                                DispatchQueue.main.async {
                                    if let stats = decodedData.description {
                                        DispatchQueue.main.async {
                                            self.subDelegate?.transferFailure(failure: stats )
                                        }
                                    }
                                    
                                }
                            }
                            
                        }
                    } catch {
                        print(error)
                    }
                //}
            //}
        }
        let task = session.dataTask(with: request, completionHandler: transferCompletionHoander)
       task.resume()
       
    }
}

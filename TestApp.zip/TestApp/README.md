### Home Assignment 
This is Readme.md file for about the iOS assignment project


* Code is properly documented in README.md
